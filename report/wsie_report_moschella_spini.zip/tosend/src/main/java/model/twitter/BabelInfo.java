package model.twitter;

import model.ObjectModel;

public class BabelInfo extends ObjectModel {
    BabelInfo(int seqId) {
        super(seqId);
    }
}
